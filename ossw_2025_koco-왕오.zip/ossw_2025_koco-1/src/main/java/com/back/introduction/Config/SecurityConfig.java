package com.back.introduction.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.web.SecurityFilterChain;

@Configuration
@EnableWebSecurity
public class SecurityConfig {

    @Bean
    public SecurityFilterChain filterChain(HttpSecurity http) throws Exception {
        http
            // 禁用CSRF保护（开发阶段）
            .csrf(csrf -> csrf.disable())
            // 配置授权规则
            .authorizeHttpRequests(authz -> authz
                // 允许访问静态资源
                .requestMatchers("/css/**", "/js/**", "/images/**", "/files/**").permitAll()
                // 允许访问所有HTML页面
                .requestMatchers("/", "/index.html", "/register.html", "/main.html", 
                               "/profile.html", "/records.html", "/detail.html").permitAll()
                // 允许访问API接口（用于前后端交互）
                .requestMatchers("/api/**").permitAll()
                // 其他请求需要认证
                .anyRequest().authenticated()
            )
            // 禁用默认登录页面
            .formLogin(form -> form.disable())
            // 禁用HTTP Basic认证
            .httpBasic(basic -> basic.disable());

        return http.build();
    }
}