package com.back.introduction.Controller;

import com.back.introduction.Dto.ResumeInputDto;
import com.back.introduction.Dto.ResumeAnalysisResultDto;
import com.back.introduction.Service.AiService;
import com.back.introduction.Util.ApiResponse;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/ai")
public class AiController {

    @Autowired
    private AiService aiService;

    @PostMapping("/analyze")
    public ApiResponse analyze(@RequestBody ResumeInputDto input) {
        ResumeAnalysisResultDto result = aiService.analyzeResume(input.getContent());
        return ApiResponse.success("분석 완료", result);
    }
}
