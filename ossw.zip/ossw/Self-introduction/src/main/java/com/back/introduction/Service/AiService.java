package com.back.introduction.Service;

import com.back.introduction.Dto.ResumeInputDto;
import com.back.introduction.Dto.ResumeAnalysisResultDto;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;
import org.springframework.http.*;

@Service
public class AiService {

    private final RestTemplate restTemplate;
    private final String FASTAPI_BASE_URL = "http://localhost:8000"; // FastAPI 运行在 8000 端口

    @Autowired
    public AiService(RestTemplate restTemplate) {
        this.restTemplate = restTemplate;
    }

    public ResumeAnalysisResultDto analyzeResume(String content) {
        String url = FASTAPI_BASE_URL + "/analyze_resume";

        ResumeInputDto inputDto = new ResumeInputDto();
        inputDto.setContent(content);

        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.APPLICATION_JSON);

        HttpEntity<ResumeInputDto> requestEntity = new HttpEntity<>(inputDto, headers);

        ResponseEntity<ResumeAnalysisResultDto> response = restTemplate.postForEntity(
                url, requestEntity, ResumeAnalysisResultDto.class);

        return response.getBody();
    }
}
