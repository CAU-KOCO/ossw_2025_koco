package com.back.introduction.Dto;

public class ResumeAnalysisResultDto {
    private int score;
    private String suggestion;

    public int getScore() {
        return score;
    }

    public void setScore(int score) {
        this.score = score;
    }

    public String getSuggestion() {
        return suggestion;
    }

    public void setSuggestion(String suggestion) {
        this.suggestion = suggestion;
    }
}
