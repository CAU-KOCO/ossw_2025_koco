from pydantic import BaseModel

class ResumeInput(BaseModel):
    content: str

class ResumeAnalysisResult(BaseModel):
    score: int
    suggestion: str