const express = require('express');
const { protect } = require('../middleware/auth');

const router = express.Router();

// 反馈路由
// 피드백 라우트
router.post('/submit', protect, (req, res) => {
  // 临时实现，返回成功
  // 임시 구현, 성공 반환
  res.status(200).json({
    success: true,
    message: '反馈已提交',
    korMessage: '피드백이 제출되었습니다'
  });
});

module.exports = router;