const express = require('express');
const { uploadFile } = require('../controllers/uploadController');
const { protect } = require('../middleware/auth');

const router = express.Router();

// 文件上传路由
// 파일 업로드 라우트
router.post('/', protect, uploadFile);

module.exports = router;