const express = require('express');
const { protect } = require('../middleware/auth');

const router = express.Router();

// 历史记录路由
// 기록 라우트
router.get('/uploads/:userId', protect, (req, res) => {
  // 临时实现，返回空数组
  // 임시 구현, 빈 배열 반환
  res.status(200).json([]);
});

router.delete('/delete/:fileId', protect, (req, res) => {
  // 临时实现，返回成功
  // 임시 구현, 성공 반환
  res.status(200).json({ success: true });
});

module.exports = router;