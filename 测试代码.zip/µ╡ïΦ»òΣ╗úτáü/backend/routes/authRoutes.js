const express = require('express');
const { register, login } = require('../controllers/authController');

const router = express.Router();

// 注册和登录路由
// 등록 및 로그인 라우트
router.post('/register', register);
router.post('/login', login);

module.exports = router;