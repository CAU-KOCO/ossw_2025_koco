const express = require('express');
const { protect } = require('../middleware/auth');

const router = express.Router();

// 用户信息路由
// 사용자 정보 라우트
router.get('/:userId', protect, (req, res) => {
  // 临时实现，返回模拟用户信息
  // 임시 구현, 모의 사용자 정보 반환
  res.status(200).json({
    id: req.params.userId,
    username: '示例用户',
    email: 'example@example.com'
  });
});

router.put('/:userId', protect, (req, res) => {
  // 临时实现，返回成功
  // 임시 구현, 성공 반환
  res.status(200).json({
    success: true,
    message: '用户信息已更新',
    korMessage: '사용자 정보가 업데이트되었습니다'
  });
});

module.exports = router;