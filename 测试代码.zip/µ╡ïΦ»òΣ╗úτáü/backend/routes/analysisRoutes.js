const express = require('express');
const { protect } = require('../middleware/auth');

const router = express.Router();

// 分析路由
// 분석 라우트
router.post('/generate', protect, (req, res) => {
  // 临时实现，返回模拟分析结果
  // 임시 구현, 모의 분석 결과 반환
  res.status(200).json({
    success: true,
    analysis: '分析结果示例 / 분석 결과 예시'
  });
});

module.exports = router;