const mongoose = require('mongoose');
const bcrypt = require('bcrypt');
const jwt = require('jsonwebtoken');

const UserSchema = new mongoose.Schema({
  username: {
    type: String,
    required: [true, '请提供用户名'], // 사용자 이름을 제공해주세요
    unique: true,
    trim: true,
    maxlength: [50, '用户名不能超过50个字符'] // 사용자 이름은 50자를 초과할 수 없습니다
  },
  email: {
    type: String,
    required: [true, '请提供邮箱'], // 이메일을 제공해주세요
    unique: true,
    match: [
      /^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/,
      '请提供有效的邮箱' // 유효한 이메일을 제공해주세요
    ]
  },
  password: {
    type: String,
    required: [true, '请提供密码'], // 비밀번호를 제공해주세요
    minlength: [6, '密码至少6个字符'], // 비밀번호는 최소 6자 이상이어야 합니다
    select: false
  },
  createdAt: {
    type: Date,
    default: Date.now
  }
});

// 加密密码
// 비밀번호 암호화
UserSchema.pre('save', async function(next) {
  if (!this.isModified('password')) {
    next();
  }
  const salt = await bcrypt.genSalt(10);
  this.password = await bcrypt.hash(this.password, salt);
});

// 生成JWT Token
// JWT 토큰 생성
UserSchema.methods.getSignedJwtToken = function() {
  return jwt.sign({ id: this._id }, process.env.JWT_SECRET, {
    expiresIn: process.env.JWT_EXPIRE
  });
};

// 验证密码
// 비밀번호 검증
UserSchema.methods.matchPassword = async function(enteredPassword) {
  return await bcrypt.compare(enteredPassword, this.password);
};

module.exports = mongoose.model('User', UserSchema);