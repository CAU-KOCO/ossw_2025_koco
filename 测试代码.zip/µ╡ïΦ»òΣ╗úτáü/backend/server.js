const express = require('express');
const cors = require('cors');
const dotenv = require('dotenv');
const connectDB = require('./config/db');
const path = require('path');

// 加载环境变量
// 환경 변수 로드
dotenv.config();

// 连接数据库
// 데이터베이스 연결
connectDB();

const app = express();

// 中间件
// 미들웨어
app.use(cors());
app.use(express.json());
app.use(express.urlencoded({ extended: true }));
app.use('/uploads', express.static(path.join(__dirname, 'uploads')));

// 路由
// 라우트
app.use('/api/auth', require('./routes/authRoutes'));
app.use('/api/upload', require('./routes/uploadRoutes'));
app.use('/api/history', require('./routes/historyRoutes'));
app.use('/api/analysis', require('./routes/analysisRoutes'));
app.use('/api/feedback', require('./routes/feedbackRoutes'));
app.use('/api/user', require('./routes/userRoutes'));

// 错误处理中间件
// 오류 처리 미들웨어
app.use((err, req, res, next) => {
  console.error(err.stack);
  res.status(500).json({ message: '服务器错误', error: process.env.NODE_ENV === 'development' ? err.message : undefined });
});

const PORT = process.env.PORT || 5000;

app.listen(PORT, () => {
  console.log(`服务器运行在端口 ${PORT}`);
  console.log(`서버가 포트 ${PORT}에서 실행 중입니다`);
});