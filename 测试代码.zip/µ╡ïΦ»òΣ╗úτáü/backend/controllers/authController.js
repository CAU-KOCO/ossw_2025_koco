const User = require('../models/User');

// @desc    注册用户
// @route   POST /api/auth/register
// @access  Public
// @desc    사용자 등록
// @route   POST /api/auth/register
// @access  Public
exports.register = async (req, res) => {
  try {
    const { username, email, password, confirmPassword } = req.body;

    // 验证密码确认
    // 비밀번호 확인 검증
    if (password !== confirmPassword) {
      return res.status(400).json({ message: '密码不匹配', korMessage: '비밀번호가 일치하지 않습니다' });
    }

    // 检查用户是否已存在
    // 사용자가 이미 존재하는지 확인
    const existingUser = await User.findOne({ email });
    if (existingUser) {
      return res.status(400).json({ message: '邮箱已被注册', korMessage: '이메일이 이미 등록되어 있습니다' });
    }

    // 创建用户
    // 사용자 생성
    const user = await User.create({
      username,
      email,
      password
    });

    // 生成token并返回
    // 토큰 생성 및 반환
    sendTokenResponse(user, 201, res);
  } catch (error) {
    res.status(500).json({
      message: '服务器错误',
      korMessage: '서버 오류',
      error: error.message
    });
  }
};

// @desc    用户登录
// @route   POST /api/auth/login
// @access  Public
// @desc    사용자 로그인
// @route   POST /api/auth/login
// @access  Public
exports.login = async (req, res) => {
  try {
    const { email, password } = req.body;

    // 验证邮箱和密码
    // 이메일 및 비밀번호 검증
    if (!email || !password) {
      return res.status(400).json({ 
        message: '请提供邮箱和密码',
        korMessage: '이메일과 비밀번호를 제공해주세요'
      });
    }

    // 检查用户是否存在
    // 사용자 존재 여부 확인
    const user = await User.findOne({ email }).select('+password');
    if (!user) {
      return res.status(401).json({ 
        message: '无效的凭据',
        korMessage: '유효하지 않은 자격 증명'
      });
    }

    // 检查密码是否匹配
    // 비밀번호 일치 여부 확인
    const isMatch = await user.matchPassword(password);
    if (!isMatch) {
      return res.status(401).json({ 
        message: '无效的凭据',
        korMessage: '유효하지 않은 자격 증명'
      });
    }

    // 生成token并返回
    // 토큰 생성 및 반환
    sendTokenResponse(user, 200, res);
  } catch (error) {
    res.status(500).json({ 
      message: '服务器错误', 
      korMessage: '서버 오류',
      error: error.message 
    });
  }
};

// 生成token响应
// 토큰 응답 생성
const sendTokenResponse = (user, statusCode, res) => {
  const token = user.getSignedJwtToken();

  res.status(statusCode).json({
    success: true,
    token,
    user: {
      id: user._id,
      username: user.username,
      email: user.email
    }
  });
};