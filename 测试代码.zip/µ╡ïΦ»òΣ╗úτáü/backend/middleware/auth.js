const jwt = require('jsonwebtoken');
const User = require('../models/User');

// 保护路由中间件
// 라우트 보호 미들웨어
exports.protect = async (req, res, next) => {
  let token;

  if (
    req.headers.authorization &&
    req.headers.authorization.startsWith('Bearer')
  ) {
    token = req.headers.authorization.split(' ')[1];
  }

  if (!token) {
    return res.status(401).json({ message: '未授权访问', korMessage: '인증되지 않은 접근입니다' });
  }

  try {
    const decoded = jwt.verify(token, process.env.JWT_SECRET);
    req.user = await User.findById(decoded.id);
    next();
  } catch (err) {
    return res.status(401).json({ message: '未授权访问', korMessage: '인증되지 않은 접근입니다' });
  }
};