const File = require('../models/File');
const multer = require('multer');
const path = require('path');
const fs = require('fs');

// 저장소 구성 (存储配置)
const storage = multer.diskStorage({
  destination: (req, file, cb) => {
    const uploadDir = 'uploads/';
    if (!fs.existsSync(uploadDir)) {
      fs.mkdirSync(uploadDir, { recursive: true });
    }
    cb(null, uploadDir);
  },
  filename: (req, file, cb) => {
    cb(null, `${Date.now()}-${file.originalname}`);
  }
});

// 파일 필터 (文件过滤器)
const fileFilter = (req, file, cb) => {
  const allowedTypes = ['.txt', '.docx'];
  const ext = path.extname(file.originalname).toLowerCase();
  
  if (allowedTypes.includes(ext)) {
    cb(null, true);
  } else {
    cb(new Error('.txt 또는 .docx 파일만 업로드할 수 있습니다'), false);
  }
};

// 업로드 설정 (上传配置)
const upload = multer({
  storage,
  fileFilter,
  limits: { fileSize: 5 * 1024 * 1024 } // 5MB
}).single('file');

// @desc    파일 업로드
// @route   POST /api/upload
// @access  Private
// 파일을 업로드하고 데이터베이스에 저장하는 함수입니다. 사용자 인증이 필요합니다.
exports.uploadFile = (req, res) => {
  upload(req, res, async (err) => {
    if (err) {
      return res.status(400).json({ message: err.message });
    }

    if (!req.file) {
      return res.status(400).json({ message: '파일을 업로드해주세요' });
    }

    try {
      const file = await File.create({
        user: req.user.id,
        filename: req.file.filename,
        originalname: req.file.originalname,
        path: req.file.path,
        mimetype: req.file.mimetype,
        size: req.file.size,
        // 분석 및 피드백 내용 시뮬레이션 (模拟分析和反馈内容)
        analysis: `<p>파일 분석 결과</p>`
      });

      res.status(201).json({
        success: true,
        data: file
      });
    } catch (error) {
      res.status(500).json({
        message: '서버 오류가 발생했습니다'
      });
    }
  });
};