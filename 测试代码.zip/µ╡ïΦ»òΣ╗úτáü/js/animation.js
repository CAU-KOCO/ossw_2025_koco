// 加载动画相关功能
document.addEventListener('DOMContentLoaded', function() {
    // 这里可以添加更多复杂的动画效果
    // 目前基本动画已在CSS中实现
});