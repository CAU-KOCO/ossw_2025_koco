/**
 * API接口封装
 * 实现与后端服务器的通信
 * 
 * API 인터페이스 래핑
 * 백엔드 서버와의 통신 구현
 */

const API_BASE_URL = 'https://api.example.com'; // 替换为实际的API基础URL // 실제 API 기본 URL로 대체

// 存储用户令牌
// 사용자 토큰 저장
let userToken = localStorage.getItem('userToken') || '';

// 通用请求函数
// 일반 요청 함수
async function request(endpoint, options = {}) {
    const url = `${API_BASE_URL}${endpoint}`;
    
    // 默认请求头
    // 기본 요청 헤더
    const headers = {
        'Content-Type': 'application/json',
        ...options.headers
    };
    
    // 如果有令牌，添加到请求头
    // 토큰이 있으면 요청 헤더에 추가
    if (userToken) {
        headers['Authorization'] = `Bearer ${userToken}`;
    }
    
    try {
        const response = await fetch(url, {
            ...options,
            headers
        });
        
        // 检查响应状态
        // 응답 상태 확인
        if (!response.ok) {
            const errorData = await response.json().catch(() => ({}));
            throw new Error(errorData.message || `请求失败: ${response.status}`);
        }
        
        // 如果响应为204 No Content，返回null
        // 응답이 204 No Content인 경우 null 반환
        if (response.status === 204) {
            return null;
        }
        
        // 解析JSON响应
        // JSON 응답 파싱
        return await response.json();
    } catch (error) {
        console.error('API请求错误:', error);
        console.error('API 요청 오류:', error);
        throw error;
    }
}

/**
 * 1. 认证模块
 * 1. 인증 모듈
 */
const auth = {
    // 用户注册
    // 사용자 등록
    async register(userData) {
        const result = await request('/api/auth/register', {
            method: 'POST',
            body: JSON.stringify(userData)
        });
        return result;
    },
    
    // 用户登录
    // 사용자 로그인
    async login(credentials) {
        const result = await request('/api/auth/login', {
            method: 'POST',
            body: JSON.stringify(credentials)
        });
        
        // 保存令牌
        // 토큰 저장
        if (result && result.token) {
            userToken = result.token;
            localStorage.setItem('userToken', userToken);
        }
        
        return result;
    },
    
    // 退出登录
    // 로그아웃
    logout() {
        userToken = '';
        localStorage.removeItem('userToken');
    }
};

/**
 * 2. 上传模块
 */
const upload = {
    // 上传文件
    async uploadFile(file, userId) {
        const formData = new FormData();
        formData.append('file', file);
        formData.append('userId', userId);
        
        const result = await fetch(`${API_BASE_URL}/api/upload`, {
            method: 'POST',
            headers: {
                'Authorization': `Bearer ${userToken}`
            },
            body: formData
        }).then(response => {
            if (!response.ok) {
                throw new Error(`上传失败: ${response.status}`);
            }
            return response.json();
        });
        
        return result;
    }
};

/**
 * 3. 历史记录模块
 */
const history = {
    // 获取上传历史
    async getUploads(userId) {
        return await request(`/api/history/uploads/${userId}`, {
            method: 'GET'
        });
    },
    
    // 删除上传记录
    async deleteRecord(fileId) {
        return await request(`/api/history/delete/${fileId}`, {
            method: 'DELETE'
        });
    }
};

/**
 * 4. 分析模块
 */
const analysis = {
    // 触发分析
    async generateAnalysis(data) {
        return await request('/api/analysis/generate', {
            method: 'POST',
            body: JSON.stringify(data)
        });
    }
};

/**
 * 5. 用户反馈模块
 */
const feedback = {
    // 提交反馈
    async submitFeedback(feedbackData) {
        return await request('/api/feedback/submit', {
            method: 'POST',
            body: JSON.stringify(feedbackData)
        });
    }
};

/**
 * 6. 用户信息模块
 */
const user = {
    // 获取用户信息
    async getUserInfo(userId) {
        return await request(`/api/user/${userId}`, {
            method: 'GET'
        });
    },
    
    // 修改用户信息
    async updateUserInfo(userId, userData) {
        return await request(`/api/user/${userId}`, {
            method: 'PUT',
            body: JSON.stringify(userData)
        });
    }
};

// 导出API模块
const api = {
    auth,
    upload,
    history,
    analysis,
    feedback,
    user
};

export default api;