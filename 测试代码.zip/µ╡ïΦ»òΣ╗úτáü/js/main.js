// 在文件顶部导入API模块
// 파일 상단에 API 모듈 가져오기
import api from './api.js';

document.addEventListener('DOMContentLoaded', function() {
    // 登录表单处理
    // 로그인 폼 처리
    const loginForm = document.getElementById('login-form');
    if (loginForm) {
        loginForm.addEventListener('submit', async function(e) {
            e.preventDefault();
            const username = document.getElementById('username').value;
            const password = document.getElementById('password').value;

            if (username && password) {
                try {
                    // 调用登录API
                    // 로그인 API 호출
                    const result = await api.auth.login({
                        email: username, // 假设用户名是邮箱 // 사용자 이름이 이메일이라고 가정
                        password: password
                    });
                    
                    // 登录成功，保存用户信息并跳转
                    // 로그인 성공, 사용자 정보 저장 및 리디렉션
                    localStorage.setItem('currentUser', JSON.stringify({
                        username: result.username,
                        email: result.email,
                        id: result.userId
                    }));
                    
                    window.location.href = 'main.html';
                } catch (error) {
                    alert(`로그인 실패: ${error.message}`);
                }
            } else {
                alert('사용자 이름과 비밀번호를 입력하세요');
            }
        });
    }

    // 注册表单处理
    const registerForm = document.getElementById('register-form');
    if (registerForm) {
        registerForm.addEventListener('submit', async function(e) {
            e.preventDefault();
            const username = document.getElementById('reg-username').value;
            const email = document.getElementById('reg-email').value;
            const password = document.getElementById('reg-password').value;

            if (username && email && password) {
                try {
                    // 调用注册API
                    await api.auth.register({
                        username,
                        email,
                        password,
                        confirmPassword: password // 假设确认密码与密码相同
                    });
                    
                    alert('등록 성공!');
                    window.location.href = 'index.html';
                } catch (error) {
                    alert(`등록 실패: ${error.message}`);
                }
            } else {
                alert('모든 필수 항목을 작성하세요');
            }
        });
    }

    // 个人资料表单处理
    const profileForm = document.getElementById('profile-form');
    if (profileForm) {
        // 获取当前用户信息并填充表单
        const currentUser = JSON.parse(localStorage.getItem('currentUser') || '{}');
        if (!currentUser.id) {
            // 未登录，重定向到登录页面
            window.location.href = 'index.html';
            return;
        }

        // 加载用户信息
        (async function() {
            try {
                const userInfo = await api.user.getUserInfo(currentUser.id);
                
                const profileUsername = document.getElementById('profile-username');
                const profileEmail = document.getElementById('profile-email');

                if (profileUsername && profileEmail) {
                    profileUsername.value = userInfo.username;
                    profileEmail.value = userInfo.email || '';
                }
            } catch (error) {
                console.error('获取用户信息失败:', error);
            }
        })();

        // 处理表单提交
        profileForm.addEventListener('submit', async function(e) {
            e.preventDefault();
            const newUsername = document.getElementById('profile-username').value;
            const newEmail = document.getElementById('profile-email').value;
            const newPassword = document.getElementById('profile-password').value;
            const confirmPassword = document.getElementById('profile-password-confirm').value;

            // 验证表单
            if (!newUsername || !newEmail) {
                alert('사용자 이름과 이메일은 필수 항목입니다');
                return;
            }

            // 如果输入了密码，验证两次输入是否一致
            if (newPassword && newPassword !== confirmPassword) {
                alert('비밀번호가 일치하지 않습니다');
                return;
            }

            try {
                // 准备更新数据
                const updateData = {
                    username: newUsername,
                    email: newEmail
                };
                
                // 如果输入了新密码，添加到更新数据中
                if (newPassword) {
                    updateData.password = newPassword;
                }
                
                // 调用更新用户信息API
                await api.user.updateUserInfo(currentUser.id, updateData);
                
                // 更新本地存储的用户信息
                localStorage.setItem('currentUser', JSON.stringify({
                    ...currentUser,
                    username: newUsername,
                    email: newEmail
                }));
                
                alert('프로필이 성공적으로 업데이트되었습니다');
            } catch (error) {
                alert(`프로필 업데이트 실패: ${error.message}`);
            }
        });
    }

    // 退出登录
    const logoutBtn = document.getElementById('logout-btn');
    if (logoutBtn) {
        logoutBtn.addEventListener('click', function(e) {
            e.preventDefault();
            api.auth.logout();
            localStorage.removeItem('currentUser');
            window.location.href = 'index.html';
        });
    }

    // 文件上传区域
    const uploadArea = document.getElementById('upload-area');
    const fileInput = document.getElementById('file-input');
    const uploadPlaceholder = document.getElementById('upload-placeholder');
    const uploadProgress = document.getElementById('upload-progress');

    if (uploadArea && fileInput) {
        // 确保初始状态正确
        uploadPlaceholder.style.display = 'flex';
        uploadProgress.style.display = 'none';

        // 点击上传区域触发文件选择
        uploadArea.addEventListener('click', function() {
            fileInput.click();
        });

        // 拖拽文件处理
        uploadArea.addEventListener('dragover', function(e) {
            e.preventDefault();
            uploadArea.classList.add('dragover');
        });

        uploadArea.addEventListener('dragleave', function() {
            uploadArea.classList.remove('dragover');
        });

        uploadArea.addEventListener('drop', function(e) {
            e.preventDefault();
            uploadArea.classList.remove('dragover');

            if (e.dataTransfer.files.length) {
                handleFile(e.dataTransfer.files[0]);
            }
        });

        // 文件选择处理
        fileInput.addEventListener('change', function() {
            if (fileInput.files.length) {
                handleFile(fileInput.files[0]);
            }
        });

        // 处理上传的文件
        function handleFile(file) {
            // 检查文件类型
            const validTypes = ['.txt', '.docx', 'text/plain', 'application/vnd.openxmlformats-officedocument.wordprocessingml.document'];
            const fileType = file.type || file.name.substring(file.name.lastIndexOf('.'));

            if (!validTypes.some(type => fileType.includes(type))) {
                alert('.txt 또는 .docx 파일을 업로드하세요');
                return;
            }

            // 显示加载动画
            uploadPlaceholder.style.display = 'none';
            uploadProgress.style.display = 'flex';

            // 获取当前用户ID
            const currentUser = JSON.parse(localStorage.getItem('currentUser') || '{}');
            const userId = currentUser.id;

            if (!userId) {
                alert('로그인이 필요합니다');
                uploadProgress.style.display = 'none';
                uploadPlaceholder.style.display = 'block';
                return;
            }

            // 上传文件并获取分析结果
            (async function() {
                try {
                    // 上传文件
                    const uploadResult = await api.upload.uploadFile(file, userId);
                    
                    // 触发分析
                    const analysisResult = await api.analysis.generateAnalysis({
                        userId,
                        fileId: uploadResult.fileId,
                        analysisType: 'full' // 假设分析类型为完整分析
                    });
                    
                    // 隐藏加载动画
                    uploadProgress.style.display = 'none';
                    uploadPlaceholder.style.display = 'block';
                    
                    // 更新分析结果和反馈
                    const analysisResultElement = document.getElementById('analysis-result');
                    const feedbackContentElement = document.getElementById('feedback-content');
                    
                    if (analysisResultElement && feedbackContentElement && analysisResult) {
                        analysisResultElement.innerHTML = `<p>파일 "${file.name}"의 분석 결과:</p><p>${analysisResult.analysis || '분석 결과가 없습니다'}</p>`;
                        feedbackContentElement.innerHTML = `<p>분석 기반 피드백:</p><p>${analysisResult.feedback || '피드백이 없습니다'}</p>`;
                    }
                } catch (error) {
                    // 隐藏加载动画
                    uploadProgress.style.display = 'none';
                    uploadPlaceholder.style.display = 'block';
                    
                    alert(`파일 처리 실패: ${error.message}`);
                }
            })();
        }

        // 显示记录
        function displayRecords() {
            const recordsContainer = document.querySelector('.records-container');
            if (!recordsContainer) return;
            
            // 获取当前用户ID
            const currentUser = JSON.parse(localStorage.getItem('currentUser') || '{}');
            const userId = currentUser.id;
            
            if (!userId) {
                window.location.href = 'index.html';
                return;
            }
            
            // 获取记录
            (async function() {
                try {
                    const records = await api.history.getUploads(userId);
                    
                    // 清空现有内容
                    const recordsList = recordsContainer.querySelector('.records-list') || document.createElement('div');
                    recordsList.className = 'records-list';
                    recordsList.innerHTML = '';
                    
                    // 添加记录
                    records.forEach(record => {
                        const recordItem = document.createElement('div');
                        recordItem.className = 'record-item';
                        
                        // 格式化日期
                        const date = new Date(record.timestamp);
                        const formattedDate = `${date.getFullYear()}년 ${date.getMonth() + 1}월 ${date.getDate()}일 ${date.getHours()}:${date.getMinutes()}`;
                        
                        recordItem.innerHTML = `
                            <div class="record-header">
                                <span class="record-date">${formattedDate}</span>
                                <a href="detail.html?id=${record.id}" class="btn btn-small">
                                    <i class="fas fa-eye"></i> 상세 보기
                                </a>
                            </div>
                            <div class="record-content">
                                <div class="record-analysis">
                                    <h4>분석 결과</h4>
                                    <div class="record-text highlighted">${record.analysis || ''}</div>
                                </div>
                                <div class="record-feedback">
                                    <h4>피드백</h4>
                                    <div class="record-text">${record.feedback || ''}</div>
                                </div>
                            </div>
                        `;
                        recordsList.appendChild(recordItem);
                    });
                    
                    // 如果recordsList不在container中，添加它
                    if (!recordsContainer.contains(recordsList)) {
                        recordsContainer.appendChild(recordsList);
                    }
                } catch (error) {
                    console.error('获取记录失败:', error);
                    recordsContainer.innerHTML = `<p class="error-message">기록을 가져오는 중 오류가 발생했습니다: ${error.message}</p>`;
                }
            })();
        }

        // 详情页面处理
        if (window.location.pathname.includes('detail.html')) {
            const urlParams = new URLSearchParams(window.location.search);
            const recordId = urlParams.get('id');

            if (recordId) {
                // 获取记录详情
                (async function() {
                    try {
                        // 假设API提供了获取单个记录的接口
                        const record = await api.history.getRecordDetail(recordId);
                        
                        const detailAnalysis = document.getElementById('detail-analysis');
                        const detailFeedback = document.getElementById('detail-feedback');
                        const detailDate = document.querySelector('.detail-date');
                        
                        if (detailAnalysis && detailFeedback && detailDate && record) {
                            detailAnalysis.innerHTML = `<p>${record.analysis || ''}</p>`;
                            detailFeedback.innerHTML = `<p>${record.feedback || ''}</p>`;
                            
                            // 格式化日期
                            const date = new Date(record.timestamp);
                            detailDate.textContent = `${date.getFullYear()}년 ${date.getMonth() + 1}월 ${date.getDate()}일 ${date.getHours()}:${date.getMinutes()}`;
                        }
                    } catch (error) {
                        console.error('获取记录详情失败:', error);
                        document.querySelector('.detail-container').innerHTML = `<p class="error-message">기록 세부 정보를 가져오는 중 오류가 발생했습니다: ${error.message}</p>`;
                    }
                })();
            }
        }

        // 在页面加载时显示记录
        if (document.querySelector('.records-container')) {
            displayRecords();
        }
    });