-- 创建数据库（如果尚不存在）
CREATE DATABASE IF NOT EXISTS introduction
    DEFAULT CHARACTER SET utf8mb4
    COLLATE utf8mb4_general_ci;

-- 切换使用该数据库
USE introduction;

-- 用户表
CREATE TABLE IF NOT EXISTS users (
                                     id BIGINT AUTO_INCREMENT PRIMARY KEY,
                                     email VARCHAR(255) NOT NULL UNIQUE,
                                     password VARCHAR(255) NOT NULL,
                                     username VARCHAR(100),
                                     created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- 上传文件记录表
CREATE TABLE IF NOT EXISTS upload_files (
                                            id BIGINT AUTO_INCREMENT PRIMARY KEY,
                                            user_id BIGINT,
                                            original_filename VARCHAR(255),
                                            stored_filename VARCHAR(255),
                                            file_path TEXT,
                                            upload_time TIMESTAMP,
                                            is_favorite BOOLEAN DEFAULT FALSE,
                                            folder_name VARCHAR(100),
                                            FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
);

-- AI 分析结果表
CREATE TABLE IF NOT EXISTS analysis_results (
                                                id BIGINT AUTO_INCREMENT PRIMARY KEY,
                                                file_id BIGINT,
                                                user_id BIGINT,
                                                score INT,
                                                suggestion TEXT,
                                                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                                                FOREIGN KEY (file_id) REFERENCES upload_files(id) ON DELETE CASCADE,
                                                FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
);

-- 用户反馈记录表
CREATE TABLE IF NOT EXISTS feedbacks (
                                         id BIGINT AUTO_INCREMENT PRIMARY KEY,
                                         user_id BIGINT,
                                         content TEXT NOT NULL,
                                         email VARCHAR(255),
                                         submitted_at TIMESTAMP,
                                         FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE SET NULL
);

DELETE FROM users;

-- 测试账户数据（明文密码，仅用于开发调试）
INSERT INTO users (email, password, username) VALUES
                                                  ('test1@example.com', '123456', 'TestUser1'),
                                                  ('test2@example.com', 'password123', 'TestUser2'),
                                                  ('admin@example.com', 'admin', 'AdminUser');