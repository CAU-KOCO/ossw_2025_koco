// API基础配置
const API_BASE_URL = ''; // 根据实际后端地址修改

// 通用API请求函数
async function apiRequest(endpoint, options = {}) {
    const url = `${API_BASE_URL}${endpoint}`;
    const config = {
        headers: {
            'Content-Type': 'application/json',
            ...options.headers
        },
        ...options
    };
    
    try {
        const response = await fetch(url, config);
        const data = await response.json();
        
        if (!data.success) {
            throw new Error(data.message || '请求失败');
        }
        
        return data;
    } catch (error) {
        console.error('API请求错误:', error);
        throw error;
    }
}

// JWT解析函数
function parseJWT(token) {
    try {
        const base64Url = token.split('.')[1];
        const base64 = base64Url.replace(/-/g, '+').replace(/_/g, '/');
        const jsonPayload = decodeURIComponent(atob(base64).split('').map(function(c) {
            return '%' + ('00' + c.charCodeAt(0).toString(16)).slice(-2);
        }).join(''));
        return JSON.parse(jsonPayload);
    } catch (error) {
        console.error('JWT解析失败:', error);
        return null;
    }
}

document.addEventListener('DOMContentLoaded', function() {
    // 登录表单处理
    const loginForm = document.getElementById('login-form');
    if (loginForm) {
        loginForm.addEventListener('submit', async function(e) {
            e.preventDefault();
            const email = document.getElementById('username').value;
            const password = document.getElementById('password').value;

            if (!email || !password) {
                alert('이메일과 비밀번호를 입력하세요');
                return;
            }

            try {
                const response = await apiRequest('/api/auth/login', {
                    method: 'POST',
                    body: JSON.stringify({
                        email: email,
                        password: password
                    })
                });
                
                // 存储JWT token和用户信息
                localStorage.setItem('authToken', response.data);
                
                // 解析JWT获取用户信息
                const userInfo = parseJWT(response.data);
                localStorage.setItem('currentUser', JSON.stringify({
                    id: userInfo?.userId || userInfo?.id,
                    email: email,
                    username: userInfo?.username
                }));
                
                alert('로그인 성공!');
                window.location.href = 'main.html';
            } catch (error) {
                alert('로그인 실패: ' + error.message);
            }
        });
    }

    // 注册表单处理
    const registerForm = document.getElementById('register-form');
    if (registerForm) {
        registerForm.addEventListener('submit', async function(e) {
            e.preventDefault();
            const username = document.getElementById('reg-username').value;
            const email = document.getElementById('reg-email').value;
            const password = document.getElementById('reg-password').value;
            const confirmPassword = document.getElementById('reg-password-confirm').value;

            // 前端验证
            if (!username || !email || !password || !confirmPassword) {
                alert('모든 필드를 입력하세요');
                return;
            }

            if (password !== confirmPassword) {
                alert('비밀번호가 일치하지 않습니다');
                return;
            }

            if (password.length < 6) {
                alert('비밀번호는 최소 6자 이상이어야 합니다');
                return;
            }

            try {
                await apiRequest('/api/auth/register', {
                    method: 'POST',
                    body: JSON.stringify({
                        email: email,
                        password: password,
                        confirmPassword: confirmPassword,
                        username: username
                    })
                });
                
                alert('등록 성공!');
                window.location.href = 'index.html';
            } catch (error) {
                alert('등록 실패: ' + error.message);
            }
        });
    }

    // 文件上传处理
    const fileInput = document.getElementById('file-input');
    const uploadArea = document.getElementById('upload-area');
    
    if (uploadArea && fileInput) {
        // 点击上传区域触发文件选择
        uploadArea.addEventListener('click', function() {
            fileInput.click();
        });

        // 拖拽文件处理
        uploadArea.addEventListener('dragover', function(e) {
            e.preventDefault();
            uploadArea.classList.add('dragover');
        });

        uploadArea.addEventListener('dragleave', function() {
            uploadArea.classList.remove('dragover');
        });

        uploadArea.addEventListener('drop', function(e) {
            e.preventDefault();
            uploadArea.classList.remove('dragover');
            
            if (e.dataTransfer.files.length) {
                fileInput.files = e.dataTransfer.files;
                handleFileUpload(e.dataTransfer.files[0]);
            }
        });

        fileInput.addEventListener('change', function(e) {
            const file = e.target.files[0];
            if (file) {
                handleFileUpload(file);
            }
        });
    }

    // 文件上传处理函数
    async function handleFileUpload(file) {
        if (!file) return;

        // 验证文件类型
        const allowedTypes = ['.pdf', '.txt'];
        const fileExtension = '.' + file.name.split('.').pop().toLowerCase();
        if (!allowedTypes.includes(fileExtension)) {
            alert('지원되지 않는 파일 형식입니다. PDF 또는 TXT 파일만 업로드 가능합니다.');
            return;
        }

        // 验证文件大小 (10MB)
        const maxSize = 10 * 1024 * 1024;
        if (file.size > maxSize) {
            alert('파일 크기가 너무 큽니다. 10MB 이하의 파일만 업로드 가능합니다.');
            return;
        }

        const formData = new FormData();
        formData.append('file', file);
        formData.append('userId', getCurrentUserId());

        try {
            showUploadProgress();
            
            const response = await fetch(`${API_BASE_URL}/api/upload`, {
                method: 'POST',
                headers: {
                    'Authorization': `Bearer ${localStorage.getItem('authToken')}`
                },
                body: formData
            });
            
            const data = await response.json();
            
            if (data.success) {
                hideUploadProgress();
                alert('파일 업로드 성공!');
                
                // 触发分析
                await triggerAnalysis(data.data.id);
            } else {
                throw new Error(data.message);
            }
        } catch (error) {
            hideUploadProgress();
            alert('파일 업로드 실패: ' + error.message);
        }
    }

    // 触发AI分析
    async function triggerAnalysis(fileId) {
        try {
            const response = await apiRequest('/api/analysis/generate', {
                method: 'POST',
                headers: {
                    'Authorization': `Bearer ${localStorage.getItem('authToken')}`
                },
                body: JSON.stringify({
                    userId: getCurrentUserId(),
                    fileId: fileId,
                    content: '可选的自我介绍文本内容',
                    analysisType: '评분/结构分析等'
                })
            });
            
            // 显示分析结果
            displayAnalysisResult(response.data);
        } catch (error) {
            console.error('분석 실패:', error);
            alert('분석 실패: ' + error.message);
        }
    }

    // 获取当前用户ID的辅助函数
    function getCurrentUserId() {
        try {
            const currentUser = JSON.parse(localStorage.getItem('currentUser') || '{}');
            if (currentUser.id) {
                return currentUser.id;
            }
            
            // 尝试从JWT token中解析用户ID
            const token = localStorage.getItem('authToken');
            if (token) {
                const userInfo = parseJWT(token);
                return userInfo?.userId || userInfo?.id || 1;
            }
            
            return 1; // 默认值
        } catch (error) {
            console.error('获取用户ID失败:', error);
            return 1;
        }
    }

    // 显示上传进度
    function showUploadProgress() {
        const uploadPlaceholder = document.getElementById('upload-placeholder');
        const uploadProgress = document.getElementById('upload-progress');
        if (uploadPlaceholder && uploadProgress) {
            uploadPlaceholder.style.display = 'none';
            uploadProgress.style.display = 'flex';
        }
    }

    // 隐藏上传进度
    function hideUploadProgress() {
        const uploadPlaceholder = document.getElementById('upload-placeholder');
        const uploadProgress = document.getElementById('upload-progress');
        if (uploadPlaceholder && uploadProgress) {
            uploadPlaceholder.style.display = 'flex';
            uploadProgress.style.display = 'none';
        }
    }

    // 显示分析结果
    function displayAnalysisResult(analysisData) {
        const resultContent = document.getElementById('analysis-result');
        if (resultContent && analysisData) {
            resultContent.innerHTML = `
                <div class="analysis-complete">
                    <h4>분석 완료</h4>
                    <p>분석 결과가 준비되었습니다.</p>
                    <div class="analysis-details">
                        ${analysisData ? JSON.stringify(analysisData, null, 2) : '분석 결과를 불러오는 중...'}
                    </div>
                </div>
            `;
        }
    }

    // 退出登录
    const logoutBtn = document.getElementById('logout-btn');
    if (logoutBtn) {
        logoutBtn.addEventListener('click', function(e) {
            e.preventDefault();
            if (confirm('정말 로그아웃하시겠습니까?')) {
                localStorage.removeItem('currentUser');
                localStorage.removeItem('authToken');
                alert('로그아웃되었습니다');
                window.location.href = 'index.html';
            }
        });
    }

    // 页面加载时检查认证状态
    function checkAuthStatus() {
        const token = localStorage.getItem('authToken');
        const currentPage = window.location.pathname.split('/').pop();
        
        // 如果在需要认证的页面但没有token，重定向到登录页
        if (!token && ['main.html', 'profile.html', 'records.html'].includes(currentPage)) {
            window.location.href = 'index.html';
            return false;
        }
        
        // 检查token是否过期
        if (token) {
            const userInfo = parseJWT(token);
            if (userInfo && userInfo.exp && userInfo.exp * 1000 < Date.now()) {
                localStorage.removeItem('authToken');
                localStorage.removeItem('currentUser');
                alert('로그인이 만료되었습니다. 다시 로그인해주세요.');
                window.location.href = 'index.html';
                return false;
            }
        }
        
        return true;
    }

    // 检查认证状态
    checkAuthStatus();
});