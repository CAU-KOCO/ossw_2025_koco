package com.back.introduction.Config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.crypto.password.NoOpPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.security.web.SecurityFilterChain;

@Configuration
public class SecurityConfig {

    @Bean
    public SecurityFilterChain securityFilterChain(HttpSecurity http) throws Exception {
        return http
                .csrf(csrf -> csrf.disable())  // 禁用 CSRF（前后端分离项目通常关闭）
                .authorizeHttpRequests(auth -> auth
                        // 允许前端静态资源访问
                        .requestMatchers(
                                "/", "/index.html", "/login.html", "register.html", "main.html", "detail.html", "profile.html", "records.html",
                                "/css/**", "/js/**", "/images/**", "/fonts/**", "/static/**"
                        ).permitAll()

                        // 允许登录注册接口
                        .requestMatchers("/api/auth/**").permitAll()

                        // 允许文件访问路径
                        .requestMatchers("/files/**").permitAll()

                        // 其他请求必须认证
                        .anyRequest().authenticated()
                )
                .formLogin(form -> form.disable())     // 禁用默认表单登录
                .httpBasic(basic -> basic.disable())   // 禁用 HTTP Basic 认证
                .build();
    }

    /**
     * 密码编码器 - 使用明文（仅供开发测试用！）
     */
    @Bean
    public PasswordEncoder passwordEncoder() {
        return NoOpPasswordEncoder.getInstance(); // ⚠️ 正式环境请使用 BCryptPasswordEncoder()
    }
}