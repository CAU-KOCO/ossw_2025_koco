package com.back.introduction.Service;

import com.back.introduction.Dto.LoginRequest;
import com.back.introduction.Dto.RegisterRequest;
import com.back.introduction.Entity.User;
import com.back.introduction.Repository.UserRepository;
import com.back.introduction.Util.ApiResponse;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import java.util.Optional;

@Service
public class AuthService {

    @Autowired
    private UserRepository userRepository;

    @Autowired
    private PasswordEncoder passwordEncoder;

    /**
     * 注册用户
     */
    public ApiResponse register(RegisterRequest request) {
        String email = request.getEmail().toLowerCase();
        // 检查邮箱是否已存在
        if (userRepository.existsByEmail(request.getEmail())) {
            return ApiResponse.error("이미 등록된 이메일입니다.");
        }

        // 检查两次密码是否一致
        if (!request.getPassword().equals(request.getConfirmPassword())) {
            return ApiResponse.error("비밀번호가 일치하지 않습니다.");
        }

        // 构造用户实体，进行密码加密
        User newUser = new User();
        newUser.setEmail(email);  // 保存小写邮箱
        newUser.setUsername(request.getUsername());
        newUser.setPassword(passwordEncoder.encode(request.getPassword()));

        userRepository.save(newUser);
        return ApiResponse.success("회원가입 성공", null);
    }

    /**
     * 登录
     */
    public ApiResponse login(LoginRequest request) {
        String email = request.getEmail().toLowerCase();
        Optional<User> optionalUser = userRepository.findByEmail(request.getEmail());

        if (optionalUser.isEmpty()) {
            return ApiResponse.error("등록되지 않은 이메일입니다.");
        }

        User user = optionalUser.get();

        // 验证密码是否匹配
        if (!passwordEncoder.matches(request.getPassword(), user.getPassword())) {
            return ApiResponse.error("비밀번호가 일치하지 않습니다.");
        }

        // 登录成功，返回用户基本信息（或生成 JWT）
        return ApiResponse.success("로그인 성공", user);
    }
}