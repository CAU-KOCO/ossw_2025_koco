package com.back.introduction.Config;

import org.springframework.context.annotation.Configuration;
import org.springframework.web.servlet.config.annotation.*;

@Configuration
public class WebConfig implements WebMvcConfigurer {

    /*
      如果你不使用跨域请求，则不需要 addCorsMappings 配置
     */

    /**
     * 映射静态资源目录（用于文件访问）
     */
    @Override
    public void addResourceHandlers(ResourceHandlerRegistry registry) {
        registry.addResourceHandler("/files/**")
                .addResourceLocations("file:uploads/"); // 修改为你的上传目录路径
    }

    /**
     * 当访问根路径 "/" 时，自动重定向到打包后的 index.html
     * 例如 http://localhost:9090/ 将访问 resources/static/index.html
     */
    @Override
    public void addViewControllers(ViewControllerRegistry registry) {
        registry.addViewController("/").setViewName("forward:/index.html");
    }
}